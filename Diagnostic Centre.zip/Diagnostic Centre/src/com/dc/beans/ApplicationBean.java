package com.dc.beans;

public class ApplicationBean {
	private String appID;
	private String firstName;
	private String lastName;
	private String gender;
	private String age;
	private String contactNumber;
	private String doctor;
	private String reason;
	private String listOfTest[];
	private String testName;
	private int amount;
	private String billID;
	
	public ApplicationBean (String firstName,String gender,String age,String contactNumber,String doctor){
		this.firstName=firstName;
		this.gender=gender;
		 this.age=age;
		 this.contactNumber=contactNumber;
		 this.doctor=doctor;
		 }
 public ApplicationBean(String firstName,String lastName,String gender,String age,String contactNumber,String doctor,String reason,String listOfTest[]){
	 this.firstName=firstName;
	 this.lastName=lastName;
	 this.gender=gender;
	 this.age=age;
	 this.contactNumber=contactNumber;
	 this.doctor=doctor;
	 this.reason=reason;
	 this.listOfTest=listOfTest;
 }
 


public ApplicationBean(String firstName,String lastName,String contactNumber,String doctor){
	this.firstName=firstName;
	 this.lastName=lastName;
	 this.contactNumber=contactNumber;
	 this.doctor=doctor;
}


public ApplicationBean(String testName,int amount){
	 this.testName=testName;
	 this.amount=amount;
	
}

public ApplicationBean(String billID){
	this.billID=billID;
}


public String getBillID() {
	return billID;
}



public void setBillID(String billID) {
	this.billID = billID;
}



public String getTestName() {
	return testName;
}



public void setTestName(String testName) {
	this.testName = testName;
}



public int getAmount() {
	return amount;
}



public void setAmount(int amount) {
	this.amount = amount;
}



public String getAppID() {
	return appID;
}


public void setAppID(String appID) {
	this.appID = appID;
}



public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getAge() {
	return age;
}

public void setAge(String age) {
	this.age = age;
}

public String getContactNumber() {
	return contactNumber;
}

public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}

public String getDoctor() {
	return doctor;
}

public void setDoctor(String doctor) {
	this.doctor = doctor;
}

public String getReason() {
	return reason;
}

public void setReason(String reason) {
	this.reason = reason;
}

public String[] getListOfTest() {
	return listOfTest;
}

public void setListOfTest(String[] listOfTest) {
	this.listOfTest = listOfTest;
}
}
