package com.dc.beans;

public class AdminBean {
	
	private String adminID;
	private String adminPass;
	
	public AdminBean() {
		// TODO Auto-generated constructor stub
	}
	
	public AdminBean(String adminID){
		this.adminID=adminID;
	}
	
	public AdminBean(String adminID,String adminPass){
		this.adminID=adminID;
		this.adminPass=adminPass;
	}

	public String getAdminID() {
		return adminID;
	}

	public void setAdminID(String adminID) {
		this.adminID = adminID;
	}

	public String getAdminPass() {
		return adminPass;
	}

	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}

}
