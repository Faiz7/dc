package com.dc.beans;

public class ReportBean {
	private String appID;
	private String testresults;

	public ReportBean(String appID){
		this.appID=appID;
		
	}

	public ReportBean(String appID,String testresults){
		this.appID=appID;
		this.testresults=testresults;
		
	}

	public String getAppID() {
		return appID;
	}

	public void setAppID(String appID) {
		this.appID = appID;
	}

	public String getTestresults() {
		return testresults;
	}

	public void setTestresults(String testresults) {
		this.testresults = testresults;
	}

}
