package com.dc.beans;

public class StaffBean {
	
	private String staffID;
	private String firstName;
	private String lastName;
	private String gender;
	private String dob;
	private String age;
	private String qualification;
	private String contactNumber;
	private String address;
	private String staffPassword;
	private String status;
	

	public StaffBean() {
		// TODO Auto-generated constructor stub
	}
	
	public StaffBean(String staffID){
		this.staffID=staffID;
	}
	
	public StaffBean(String staffID,String staffPassword){
		this.staffID=staffID;
		this.staffPassword=staffPassword;
	}
	
	public StaffBean(String staffID,String staffPassword,String status){
		this.staffID=staffID;
		this.staffPassword=staffPassword;
		this.status=status;
	}
	
	public StaffBean(String staffID,String firstName,String lastName,String gender,String dob,String age,String qualification,String contactNumber,String address,String staffPassword,String status){
		this.staffID=staffID;
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
		this.dob=dob;
		this.age=age;
		this.qualification=qualification;
		this.contactNumber=contactNumber;
		this.address=address;
		this.staffPassword=staffPassword;
		this.status=status;
	}

	
	public StaffBean(String firstName,String lastName,String gender,String dob,String age,String qualification,String contactNumber,String address,String staffPassword){
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
		this.dob=dob;
		this.age=age;
		this.qualification=qualification;
		this.contactNumber=contactNumber;
		this.address=address;
		this.staffPassword=staffPassword;
	}
	public String getStaffID() {
		return staffID;
	}

	public void setStaffID(String staffID) {
		this.staffID = staffID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStaffPassword() {
		return staffPassword;
	}

	public void setStaffPassword(String staffPassword) {
		this.staffPassword = staffPassword;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
}
