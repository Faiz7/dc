package com.dc.beans;

public class ApproveStaffBean {
	private String ID;
	private String firstName;
	private String status;

	
	
	public ApproveStaffBean() {
		// TODO Auto-generated constructor stub
	}
	
	public ApproveStaffBean(String ID,String firstName){
		this.ID=ID;
		this.firstName=firstName;
	}
	
	public ApproveStaffBean(String status){
		this.status=status;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



}
