package com.dc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.dc.beans.ReportBean;

public class ReportBeanDAO {
	public boolean IDcheck(ReportBean rb){
		 
		boolean result=false;
		 
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps1 = con.prepareStatement("select app_ID from applicationform where app_ID=?");
		 ps1.setString(1,rb.getAppID());
		 ResultSet rs1 = ps1.executeQuery();
		 while(rs1.next())
			 result=true;
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return result;
	 }

	
	public boolean addreport(ReportBean rb){
		 
		boolean result=false;
		 
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps1 = con.prepareStatement("insert into report values(?,?)");
		 ps1.setString(1,rb.getAppID());
		 ps1.setString(2,rb.getTestresults());
		 int row = ps1.executeUpdate();
		 if(row==1){
			 result=true;
		 }else{
			 result=false;
		 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return result;
	 }

	
	public boolean retrieve(ReportBean rb){
		 
		boolean result3=false;
		 
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps2 = con.prepareStatement("select app_ID from report where app_ID=?");
		 ps2.setString(1,rb.getAppID());
		 ResultSet rs2 = ps2.executeQuery();
		 System.out.println("1");
		 while(rs2.next())
			 System.out.println("2");
			 result3=true;
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return result3;
	 }
}
