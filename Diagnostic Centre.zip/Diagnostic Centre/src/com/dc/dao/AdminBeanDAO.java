package com.dc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



import com.dc.beans.AdminBean;


public class AdminBeanDAO {
	
	public boolean validateAdminID(AdminBean ab1){
		 
		boolean result1=false;
		 
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps1 = con.prepareStatement("select adminName from adminDetails where adminID=?");
		 ps1.setString(1,ab1.getAdminID());
		 ResultSet rs1 = ps1.executeQuery();
		 while(rs1.next())
			 result1=true;
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return result1;
	 }
	
	public boolean validateAdminPass(AdminBean ab2){
		 
		boolean result2=false;
		 
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps2 = con.prepareStatement("select adminName from adminDetails where adminID=? and adminPassword=?");
		 ps2.setString(1,ab2.getAdminID());
		 ps2.setString(2,ab2.getAdminPass());
		 ResultSet rs2 = ps2.executeQuery();
		 while(rs2.next())
			 result2=true;
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return result2;
	 }


}
