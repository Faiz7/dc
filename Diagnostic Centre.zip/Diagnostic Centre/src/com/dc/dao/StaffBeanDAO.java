package com.dc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.dc.beans.StaffBean;

public class StaffBeanDAO {
	public boolean validateStaffID(StaffBean sb1){
		 
		boolean result1=false;
		 
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps1 = con.prepareStatement("select firstName from staffDetails where ID=?");
		 ps1.setString(1,sb1.getStaffID());
		 ResultSet rs1 = ps1.executeQuery();
		 while(rs1.next())
			 result1=true;
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return result1;
	 }

	public boolean validateStaffPass(StaffBean sb2){
		 
		boolean result2=false;
		 
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps2 = con.prepareStatement("select firstName from staffDetails where ID=? and staffPassword=?");
		 ps2.setString(1,sb2.getStaffID());
		 ps2.setString(2,sb2.getStaffPassword());
		 ResultSet rs2 = ps2.executeQuery();
		 while(rs2.next())
			 result2=true;
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return result2;
	 }
	
	
	public boolean validateStatus(StaffBean sb3){
		 
		boolean result3=false;
		 
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps3 = con.prepareStatement("select firstName from staffDetails where ID=? and staffPassword=? and status=?");
		 ps3.setString(1,sb3.getStaffID());
		 ps3.setString(2,sb3.getStaffPassword());
		 ps3.setString(3,sb3.getStatus());
		 ResultSet rs3 = ps3.executeQuery();
		 while(rs3.next())
			 result3=true;
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return result3;
	 }
	
	public boolean registerstaff(StaffBean sb3){
		 
		
		 boolean result=false;
		 Connection con = DBUtil.getConObject();
		 try{
			 con.setAutoCommit(false);
		 PreparedStatement ps = con.prepareStatement("insert into staffdetails values(staffID_seq.nextval,?,?,?,?,?,?,?,?,?,'notapproved')");
		 ps.setString(1,sb3.getFirstName());
		 ps.setString(2,sb3.getLastName());
		 ps.setString(3, sb3.getGender());
		 ps.setString(4, sb3.getDob());
		 ps.setString(5, sb3.getAge());
		 ps.setString(6, sb3.getQualification());
		 ps.setString(7, sb3.getContactNumber());
		 ps.setString(8, sb3.getAddress());
		 ps.setString(9, sb3.getStaffPassword());
		 
		 
		 int noofrows = 0;
		 noofrows = ps.executeUpdate();
		 con.commit();
		 if(noofrows==1){
			result=true;
		 }else{
			 result=false;
		 }
		 }catch(Exception e){
				e.printStackTrace();
				try{
				con.rollback();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}finally{
				try{
				con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		return result; 
	 }
	
	

}
