package com.dc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import com.dc.beans.ApplicationBean;

public class PaymentDAO {
	
	public List<ApplicationBean> searchApplication1(String appID ){
		 
		 List<ApplicationBean> li1 = new LinkedList<ApplicationBean>();
		 Connection con = DBUtil.getConObject();
		 try{
		 PreparedStatement ps1 = con.prepareStatement("select firstName,lastName,contactnumber,doctor from applicationform where app_id=?");
		 
		 ps1.setString(1, appID);
		 System.out.println("1");
		 ResultSet rs1 = ps1.executeQuery();
		 System.out.println("2");

		 while(rs1.next()){
			   
			 String firstName = rs1.getString(1);
			 String lastName = rs1.getString(2);
			 String contactnumber = rs1.getString(3);
			 String doctor = rs1.getString(4);
			 System.out.println("3");
			 ApplicationBean ab = new ApplicationBean(firstName,lastName,contactnumber,doctor);
			 li1.add(ab);
			 System.out.println("4"); 
		
		 }

		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 
		 return li1;
	 }
	
	public List<ApplicationBean> searchApplication2(String appID ){
		System.out.println("5");
		 List<ApplicationBean> li2 = new LinkedList<ApplicationBean>();
		 Connection con = DBUtil.getConObject();
		 try{
			 System.out.println("6");
		 PreparedStatement ps2 = con.prepareStatement("select testname,amount from testcatalog where testid in (select listoftest from test where app_id=?)");	 
		 ps2.setString(1, appID);
		 ResultSet rs2 = ps2.executeQuery();
		 while(rs2.next()){
			   
			 String testName = rs2.getString(1);
			 int amount = rs2.getInt(2);
			 System.out.println("7"); 
			 
			 ApplicationBean ab2 = new ApplicationBean(testName,amount);
			 li2.add(ab2);
			 System.out.println("8"); 
		
		 }
		 
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 
		 return li2;
	 }
	
	
	public List<ApplicationBean> billID(){
	
		 List<ApplicationBean> li3 = new LinkedList<ApplicationBean>();
		 Connection con = DBUtil.getConObject();
		 try{
			 
		 PreparedStatement ps2 = con.prepareStatement("select bill_seq.nextval from dual");	 
		 
		 ResultSet rs2 = ps2.executeQuery();
		 while(rs2.next()){
			   
			 String billID = rs2.getString(1);
			
			
			 ApplicationBean ab2 = new ApplicationBean(billID);
			 li3.add(ab2);
			 
		
		 }
		 
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 
		 return li3;
	 }

}
