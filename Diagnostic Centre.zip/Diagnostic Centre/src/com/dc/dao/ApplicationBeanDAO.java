package com.dc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;

import com.dc.beans.ApplicationBean;


public class ApplicationBeanDAO {
	
	public boolean patientappform(ApplicationBean ab){
		 
		boolean result=false;
		 Connection con = DBUtil.getConObject();
		 try{
			 
		 PreparedStatement ps = con.prepareStatement("insert into applicationform values(application_seq.nextval,?,?,?,?,?,?,?)");
		
		 ps.setString(1,ab.getFirstName());
		 ps.setString(2,ab.getLastName());
		 ps.setString(3,ab.getGender());
		 ps.setString(4,ab.getAge());
		 ps.setString(5,ab.getContactNumber());
		 ps.setString(6,ab.getDoctor());
		 ps.setString(7,ab.getReason());
		 int noofrows = ps.executeUpdate();
		 
		 PreparedStatement ps1 = con.prepareStatement("insert into test values(application_seq.currval,?)");
		 int noofrows1=0;
		 for(String listOfTest : ab.getListOfTest()){
		 ps1.setString(1,listOfTest);
		 noofrows1=ps1.executeUpdate();
		 }
	
		 con.commit();
		 if(noofrows==1 && noofrows1==1)
			result=true;
		 }catch(Exception e){
				e.printStackTrace();
				try{
				con.rollback();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}finally{
				try{
				con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		return result; 
	 }
	
	public int id(){
		int a=0;
		Connection con = DBUtil.getConObject();
		try{
			 con.setAutoCommit(false);
		Statement st = con.createStatement();
		ResultSet rs1= st.executeQuery("select application_seq.nextval from dual");
		 ResultSet rs= st.executeQuery("select application_seq.currval from dual");
		 
		 while(rs.next()){
			 int currval=rs.getInt(1);
			 a= currval-1;
		 }
		 con.commit();
		}catch(Exception e){
			e.printStackTrace();
			try{
			con.rollback();
			}catch(Exception e1){
				e1.printStackTrace();
			}
			
		}finally{
			try{
			con.close();
			}catch(Exception e){
				e.printStackTrace();
			}
	}
		return a;
}
}