package com.dc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.LinkedList;
import java.util.List;

import com.dc.beans.ApproveStaffBean;


public class NewStaffApprovalDAO {


		 public List<ApproveStaffBean> status(String status){
			 
			 List<ApproveStaffBean> li = new LinkedList<ApproveStaffBean>();
			 
			 Connection con = DBUtil.getConObject();
			 try{
			 PreparedStatement ps = con.prepareStatement("select id,firstname from staffdetails where status= ?");
			 
			 ps.setString(1, status);
			 
			 ResultSet rs = ps.executeQuery();
			 
			 while(rs.next()){
				   
				 String ID =  rs.getString(1);
				 String firstName = rs.getString(2);
				 ApproveStaffBean asb = new ApproveStaffBean(ID,firstName);
				 li.add(asb);
			 }
			 }catch(Exception e){
				 e.printStackTrace();
			 }finally{
				 try{
				 con.close();
				 }catch(Exception e1){
					 e1.printStackTrace();
				 }
			 }
			 return li;
		 }
		
	}
