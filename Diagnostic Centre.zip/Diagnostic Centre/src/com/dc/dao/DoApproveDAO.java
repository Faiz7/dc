package com.dc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;


import com.dc.beans.StaffBean;

public class DoApproveDAO {
	public boolean approve(StaffBean sb){
		 
		
		 boolean result=false;
		 Connection con = DBUtil.getConObject();
		 try{
			
		 PreparedStatement ps1 = con.prepareStatement("update staffDetails set status='approved' where id=?");
		 ps1.setString(1,sb.getStaffID());
		 int noofrows = 0;
		 noofrows = ps1.executeUpdate();
	
		
		 if(noofrows==1){
			result=true;
		 }else{
			 result=false;
		 }
		 }catch(Exception e){
				e.printStackTrace();
				try{
				con.rollback();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}finally{
				try{
				con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		return result; 
	 }
	
	public boolean deny(StaffBean sb1){
		 
		
		 boolean result1=false;
		 Connection con = DBUtil.getConObject();
		 try{
			 con.setAutoCommit(false);
		 PreparedStatement ps1 = con.prepareStatement("delete from staffDetails where id=?");
		 ps1.setString(1,sb1.getStaffID());
		 int noofrows = 0;
		 noofrows = ps1.executeUpdate();
	
		 con.commit();
		 if(noofrows==1){
			result1=true;
		 }else{
			 result1=false;
		 }
		 }catch(Exception e){
				e.printStackTrace();
				try{
				con.rollback();
				}catch(Exception e1){
					e1.printStackTrace();
				}
				
			}finally{
				try{
				con.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		return result1; 
	 }
	

}

