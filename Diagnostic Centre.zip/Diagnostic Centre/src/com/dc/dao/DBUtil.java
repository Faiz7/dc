package com.dc.dao;
import java.sql.*;
//Step 0 :
public class DBUtil {

	static Connection conObject = null;
	
	public static Connection getConObject(){
		
		
		try{
			//Step 2 : Load the Database Driver Class
			Class.forName("oracle.jdbc.driver.OracleDriver");
		//Step 3 : Estabilish Connection
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String userName = "system";
			String password = "system";
			conObject = DriverManager.getConnection(url,userName,password);
	
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
		
				return conObject;
	}
	
}
