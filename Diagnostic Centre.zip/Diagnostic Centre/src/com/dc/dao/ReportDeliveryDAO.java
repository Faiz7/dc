package com.dc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import com.dc.beans.ApplicationBean;
import com.dc.beans.ReportBean;

public class ReportDeliveryDAO {
	
	
	
	public List<ApplicationBean> details(String app_ID ){
		 
		 List<ApplicationBean> li1 = new LinkedList<ApplicationBean>();
		 
		 String b=app_ID;
		 Connection con = DBUtil.getConObject();
		 try{
			 PreparedStatement ps = con.prepareStatement("select firstName,gender,age,contactNumber,doctor from applicationform where app_ID=?");
			 ps.setString(1,b);
			 
			 
			 ResultSet rs1 = ps.executeQuery();
			 
			 
		 while(rs1.next()){
			 
			 String firstName = rs1.getString(1);
			 String gender = rs1.getString(2);
			 String age = rs1.getString(3);
			 String contactNumber = rs1.getString(4);
			 String doctor = rs1.getString(5);
			 
			 ApplicationBean rb = new ApplicationBean(firstName,gender,age,contactNumber,doctor);
			
			 li1.add(rb);
			 
			 System.out.println(li1);
		 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return li1;
	 }
	
	
	
	
	public List<ReportBean> reportdelivery(String app_ID ){
		 
		 List<ReportBean> li2 = new LinkedList<ReportBean>();
		 
		 String a=app_ID;
		 Connection con = DBUtil.getConObject();
		 try{
			 PreparedStatement ps2 = con.prepareStatement("select app_id,testresults from report where app_ID=?");
			 ps2.setString(1,a);
			 
			 ResultSet rs2 = ps2.executeQuery();
			 
			 
		 while(rs2.next()){
			 
			 String appID = rs2.getString(1);
			 String testresults = rs2.getString(2);
			 
			 ReportBean rb = new ReportBean(appID,testresults);
			
			 li2.add(rb);
			 System.out.println(li2);
		 }
		 }catch(Exception e){
			 e.printStackTrace();
		 }finally{
			 try{
			 con.close();
			 }catch(Exception e1){
				 e1.printStackTrace();
			 }
		 }
		 return li2;
	 }
	
	
	

}
