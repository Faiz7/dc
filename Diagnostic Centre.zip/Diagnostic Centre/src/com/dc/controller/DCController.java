 package com.dc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dc.beans.AdminBean;
import com.dc.beans.ApplicationBean;
import com.dc.beans.ApproveStaffBean;
import com.dc.beans.ReportBean;
import com.dc.beans.StaffBean;
import com.dc.dao.AdminBeanDAO;
import com.dc.dao.ApplicationBeanDAO;
import com.dc.dao.DoApproveDAO;
import com.dc.dao.NewStaffApprovalDAO;
import com.dc.dao.PaymentDAO;
import com.dc.dao.ReportBeanDAO;
import com.dc.dao.ReportDeliveryDAO;
import com.dc.dao.StaffBeanDAO;

public class DCController extends HttpServlet {

	public void init(ServletConfig sc){
		System.out.println("Servlet Object Initialized");
	}
	//get and post
	public void service(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException {
	
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		RequestDispatcher rd = null;
		out.println("<h1>Welcome To Cargo Portal</h1>");
		
		String module = request.getParameter("module");
		
		if(module.equals("adminlogin")){
		
		String adminID = request.getParameter("adminid");
		AdminBean ab1 = new AdminBean(adminID);
		AdminBeanDAO abd1 = new AdminBeanDAO();
		boolean checkadminid=abd1.validateAdminID(ab1);
		
		String adminPass = request.getParameter("adminpass");
		AdminBean ab2 = new AdminBean(adminID,adminPass);
		AdminBeanDAO abd2 = new AdminBeanDAO();
		boolean checkadminpass=abd2.validateAdminPass(ab2);
		
		
		
		
		if(!checkadminid){
			request.setAttribute("adminiderror","Sorry Invalid UserName,Please Check!");
		}
		if(!checkadminpass){
			request.setAttribute("adminpasserror","Sorry The password Entered doesnot match username,Please Check!");
		}
		
		if(checkadminid && checkadminpass){
			rd = request.getRequestDispatcher("adminpage.jsp");
			rd.forward(request, response);
		
		}else{
			rd = request.getRequestDispatcher("dclogin.jsp");
			rd.forward(request, response);						
		
		}
		
		}else if(module.equals("stafflogin")){
			
			String staffID = request.getParameter("staffid");
			StaffBean sb1 = new StaffBean(staffID);
			StaffBeanDAO sbd1 = new StaffBeanDAO();
			boolean checkstaffid=sbd1.validateStaffID(sb1);
			
			String staffPass = request.getParameter("staffpass");
			StaffBean sb2 = new StaffBean(staffID,staffPass);
			StaffBeanDAO sbd2 = new StaffBeanDAO();
			boolean checkstaffpass=sbd2.validateStaffPass(sb2);
			
			String status = request.getParameter("status");
			StaffBean sb3 = new StaffBean(staffID,staffPass,status);
			StaffBeanDAO sbd3 = new StaffBeanDAO();
			boolean checkstatus=sbd3.validateStatus(sb3);
			
			if(!checkstaffid){
				request.setAttribute("staffiderror","Sorry Invalid UserName Please Check!");
			}
			if(!checkstaffpass){
				request.setAttribute("staffpasserror","Sorry The password Entered doesnot match username,Please Check!");
			}
			if(!checkstatus){
				request.setAttribute("staffstatuserror","Sorry you are not yet approved..!,Please contact admin!");
			}
			
			if(checkstaffid && checkstaffpass && checkstatus){
				rd = request.getRequestDispatcher("staffpage.jsp");
				rd.forward(request, response);
			
			}else{
				rd = request.getRequestDispatcher("dclogin.jsp");
				rd.forward(request, response);						
			
			}
			
			}else if(module.equals("registerstaff")){
				
				rd=request.getRequestDispatcher("registernewstaff.jsp");
				rd.forward(request, response);
				
			}else if(module.equals("staffregisterform")){
				
				String firstName = request.getParameter("firstname");
				String lastName = request.getParameter("lastname");
				String gender = request.getParameter("gender");
				String dob = request.getParameter("dob");
				String age = request.getParameter("age");
				String qualification = request.getParameter("qualification");
				String contactNumber = request.getParameter("contactnumber");
				String address = request.getParameter("address");
				String staffPassword = request.getParameter("staffpassword");
				
				StaffBean sb3 = new StaffBean(firstName,lastName,gender,dob,age,qualification,contactNumber,address,staffPassword);
				StaffBeanDAO sbd3 = new StaffBeanDAO();
				boolean check=sbd3.registerstaff(sb3);
				if(!check){
					rd=request.getRequestDispatcher("staffregistersuccess.jsp");
					rd.forward(request, response);
				}else{
				rd=request.getRequestDispatcher("staffregistersuccess.jsp");
				rd.forward(request, response);
				}
			}else if(module.equals("approve")){
				
				String status = request.getParameter("notapproved");
				
				NewStaffApprovalDAO nsad = new NewStaffApprovalDAO();
				List<ApproveStaffBean> li = nsad.status(status);
				
				rd = request.getRequestDispatcher("approvenewstaff.jsp");
				
				request.setAttribute("app", li);
				
				rd.forward(request, response);
				
			}else if(module.equals("doapprove")){
				String ID = request.getParameter("ID");
				StaffBean sb = new StaffBean(ID);
				DoApproveDAO dad=new DoApproveDAO();
				boolean approve=dad.approve(sb);
				if(!approve){
					rd=request.getRequestDispatcher("approveerror.jsp");
					rd.forward(request, response);
				}else{
				rd=request.getRequestDispatcher("approved.jsp");
				rd.forward(request, response);
				}
				
				
			}else if(module.equals("deny")){
				String ID = request.getParameter("ID");
				StaffBean sb1 = new StaffBean(ID);
				DoApproveDAO dad1=new DoApproveDAO();
				boolean deny=dad1.deny(sb1);
				if(!deny){
					rd=request.getRequestDispatcher("approveerror.jsp");
					rd.forward(request, response);
				}else{
				rd=request.getRequestDispatcher("approved.jsp");
				rd.forward(request, response);
				}
				
				
			}else if(module.equals("application")){
				String firstName = request.getParameter("fname");
				String lastName = request.getParameter("lname");
				String gender = request.getParameter("gender");
				String age = request.getParameter("age");
				String contactNumber = request.getParameter("cno");
				String doctor = request.getParameter("doctorref");
				String reason = request.getParameter("comment");
				String listOfTest[] = request.getParameterValues("tests");
				ApplicationBean ab = new ApplicationBean(firstName,lastName,gender,age,contactNumber,doctor,reason,listOfTest);
				ApplicationBeanDAO abd= new ApplicationBeanDAO();
				boolean appform=abd.patientappform(ab);
				int c = abd.id();
				if(appform){
					rd=request.getRequestDispatcher("appsuccess.jsp");
					request.setAttribute("app1", c);
					rd.forward(request, response);
				}else{
				
				rd=request.getRequestDispatcher("appfail.jsp");
				rd.forward(request, response);
				}
				
			}else if(module.equals("topayment")){
				String appID = request.getParameter("applicationno");
				rd=request.getRequestDispatcher("payment.jsp");
				request.setAttribute("apid",appID);
				rd.forward(request, response);
			}
					
			else if(module.equals("applicationID")){
				String appID = request.getParameter("aID");
				PaymentDAO pdao = new PaymentDAO();
				
				List<ApplicationBean> li1 = pdao.searchApplication1(appID);
				
				List<ApplicationBean> li2 = pdao.searchApplication2(appID);
				
				List<ApplicationBean> li3 = pdao.billID();
		
				rd = request.getRequestDispatcher("payment.jsp");
				
				request.setAttribute("applicationID1", li1);
			
				request.setAttribute("applicationID2", li2);
				
				request.setAttribute("billID", li3);
		
				rd.forward(request, response);
			}else if(module.equals("generatereport")){
				String appID = request.getParameter("appID");
				ReportBean rb = new ReportBean(appID);
				ReportBeanDAO rbd = new ReportBeanDAO();
				boolean app_ID = rbd.IDcheck(rb);
				
				if(app_ID){
					rd=request.getRequestDispatcher("generatereport.jsp");
					request.setAttribute("appID", appID);
					rd.include(request, response);
				}else{
					rd=request.getRequestDispatcher("uploadfail.jsp");
					rd.forward(request, response);
				}
		
			}else if(module.equals("reportupload")){
				String appID=request.getParameter("appID");
				String testresults = request.getParameter("testresults");
				ReportBean rb = new ReportBean(appID,testresults);
				ReportBeanDAO rbd = new ReportBeanDAO();
				boolean ad = rbd.addreport(rb);
				
				if(ad){
					rd=request.getRequestDispatcher("uploadsuccess.jsp");
					rd.forward(request, response);
				}else{
					rd=request.getRequestDispatcher("uploadfail.jsp");
					rd.forward(request, response);
				}
		
			}else if(module.equals("retrievereport")){
				String appID = request.getParameter("appID");
				ReportBean rb = new ReportBean(appID);
				ReportBeanDAO rbd = new ReportBeanDAO();
				boolean app_ID = rbd.retrieve(rb);
				
				if(app_ID){
					rd=request.getRequestDispatcher("retrievereport.jsp");
					request.setAttribute("appID", appID);
					rd.forward(request, response);
				}else{
					rd=request.getRequestDispatcher("uploadfail.jsp");
					rd.forward(request, response);
				}
		
		}else if(module.equals("retrievedata")){
			String app_ID = request.getParameter("app_ID");
			
			ReportDeliveryDAO rdd = new ReportDeliveryDAO();
			List<ApplicationBean> li1 = rdd.details(app_ID);
			
			List<ReportBean> li2 = rdd.reportdelivery(app_ID);
			
			rd = request.getRequestDispatcher("retrievereport.jsp");
			
			System.out.println(li1);
			System.out.println(li2);
			
			request.setAttribute("details", li1);
		
			request.setAttribute("report", li2);
			
	
			rd.forward(request, response);
			
			
	
	}
	
		
		
	}	
	
	public void destroy(){
		System.out.println("Servlet Object Destroyed");
	}
}